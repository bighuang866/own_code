# -*- coding: utf-8 -*-
# @Time    : 2018/10/30 14:33
# @Author  : Big Huang
# @Email   : kenhuang866@qq.com
# @File    : main2.py
# @Software: PyCharm Community Edition


from WindPy import w
w.start()
error_code, df = w.wsd(["000004.SZ", "000005.SZ"], "open", "2018-09-30", "2018-10-29", "", usedf=True)







